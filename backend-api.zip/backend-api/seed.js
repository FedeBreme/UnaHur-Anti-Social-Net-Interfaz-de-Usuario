const { sequelize, User, Post, Comment, Tag, PostImage } = require('./models');

async function seed() {
  await sequelize.sync({ force: true });

  const user1 = await User.create({ nickName: 'luna', email: 'luna@example.com' });
  const user2 = await User.create({ nickName: 'sol', email: 'sol@example.com' });

  const tag1 = await Tag.create({ name: 'arte' });
  const tag2 = await Tag.create({ name: 'unahur' });

  const post1 = await Post.create({ description: 'Mi primer post', UserId: user1.id });
  const post2 = await Post.create({ description: 'Reflexiones nocturnas', UserId: user2.id });

  await post1.setTags([tag1, tag2]);
  await post2.setTags([tag1]);

  await Comment.create({ content: 'Muy bueno!', UserId: user2.id, PostId: post1.id });
  await Comment.create({ content: 'Gracias por compartir', UserId: user1.id, PostId: post2.id });

  await PostImage.bulkCreate([
    {
      url: 'https://wallpapers.com/images/hd/cute-stitch-pictures-0bmjcesfg6ulg2hm.jpg',
      PostId: post1.id
    },
    {
      url: 'https://i.blogs.es/8256d5/gpu-openai-chatgpt/500_333.jpeg',
      PostId: post1.id
    },
    {
      url: 'https://images.ctfassets.net/hrltx12pl8hq/01rJn4TormMsGQs1ZRIpzX/16a1cae2440420d0fd0a7a9a006f2dcb/Artboard_Copy_231.jpg?fit=fill&w=480&h=400',
      PostId: post2.id
    }
  ]);

  console.log('Base de datos poblada!');
  process.exit();
}

seed();